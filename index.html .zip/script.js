let yesSize = 1;

function moveNo() {
  let x = Math.random() * 200 - 100;
  let y = Math.random() * 200 - 100;

  const noBtn = document.getElementById("noBtn");
  noBtn.style.transform = `translate(${x}px, ${y}px)`;

  // Make YES bigger when NO is touched
  yesSize += 0.2;
  document.getElementById("yesBtn").style.transform = `scale(${yesSize})`;
}

function acceptYes() {
  showResult();
}

function autoYes() {
  showResult();
}

function showResult() {
  document.querySelector(".buttons").style.display = "none";
  document.getElementById("title").innerText = "YAYYYY 🥰🎉";
  document.getElementById("subtitle").innerText = "You just made me very happy 💘";
  document.getElementById("result").classList.remove("hidden");
}